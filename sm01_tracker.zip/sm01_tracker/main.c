/*******************************************************************
 *  A simple GPS tracker application using SM01 module and ublox
 *  SAM-M8Q GPS receiver module.
 *******************************************************************
 * File:    main.c
 * Company: SciFlair Ltd.
 * Notes: 
 *    1) Compiler XC16 v1.25 was used to compile this project,  
 *       using another version might produce errors. 
 * 
 * Copyright (C)2019 SciFlair Ltd. - All Rights Reserved.
 * 
 * You may use, modify, copy and distribute these codes to be used 
 * solely on AXINO SM01 modules.
 *   
 * Author            Date        Comment
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * AAC               18/08/2019  Original release
 ********************************************************************/

#include <xc.h>
#include "sm01_lib/sm01.h"
#include <string.h>

//Application variables
static struct 
{
    uint32_t UTC;
    char status;
    char NS;
    char EW;
    double Longitude;
    double Latitude;    
    double Speed;
} gpsData; 

static uint16_t updateInterval = 60;
static bool requireUpdate = false;
static bool updateReady = false;

//Function prototypes
void ProcessGPSTask(void);

//Main program begins here
int main(void)
{
    SM01_Init(SM01_MODULE_IN_USE, SM01_MODE_AUTO); //Initialize SM01 hardware and all its required modules
    EZCOM_SetTrace(1); //Enable EZCOM stack operation to be reported on console
    UART1_Open(9600);  //Open UART1 at 9600 baud 

    while(1)
    {
        ProcessGPSTask(); //Process task related to GPS receiver
        
        if(SW_IO == 0 || updateReady == true) //publish to cloud if update is required, or switch on module is pressed 
        {
            char buf[100];
            updateReady = false;

            sprintf(buf, "Latitude: %c%f, Longitude:%c%f, Speed: %u",gpsData.NS, gpsData.Latitude, gpsData.EW, gpsData.Longitude, (uint16_t)gpsData.Speed);
            printf("\r\nSending Message to Cloud {%s}", buf);

            if(EZCOM_IsConnected())
            {
                if(EZCOM_Publish(1, buf, true, EZCOM_QOS_1))
                        printf("\r\nMessage Sent!");
                else printf("\r\nMessage Failed!");
            }
            else printf("\r\nCloud is not connected");
            TickWait(500);
            //SM01_Sleep(5);
        }
    }
}

// This function is called by sm01 stack every time a new message is received from cloud
bool EZCOM_OnReceive(uint32_t from, uint32_t topic, uint8_t* msg, uint16_t msglen)
{
    if(msglen >=6 && strncmp("getpos", (char*)msg,6) == 0)
    {
        printf("\r\nGPS position request is received ");
        requireUpdate = true;
    }
    else if(msglen >=11 && strncmp("interval=", (char*)msg,9) == 0)
    {
        updateInterval = atoi((char*)msg+9);
        if(updateInterval < 30) updateInterval = 30;        //limit max value to 30 seconds
        if(updateInterval > 3600) updateInterval = 3600;    //limit max value to 3600 seconds (1 hour) 
        printf("\r\nUpdate interval is set to %u Seconds", updateInterval);
    }
    else printf("\r\nUnknown Message");
    
    return true;
}

//This function process task related to GPS functionality
void ProcessGPSTask(void)
{
    uint16_t w,x,i;
    uint8_t buf[64];
    static uint32_t lastUpdateTime = 0;
    
    //check the time in seconds since last update and set flag for update if update interval is past.
    if((SM01_UpTime() - lastUpdateTime) >  updateInterval)
    {
        lastUpdateTime = SM01_UpTime();   
        requireUpdate = true;        
    }
    
    w = UART1_Readable(); // Get count of RX bytes waiting in FIFO
    if(w >= 6)
    {
        if(w > sizeof(buf)) w = sizeof(buf);
        x = UART1_Find((uint8_t*)"$GNRMC" , 6);
        if(x < w){
            
            UART1_Read(buf, x);         //read and discard everything before $GNRMC
            if(w>=64)
            {
                char* ptr;
                UART1_Read(buf, 64);    //read message from UART starting with $GNRMC
                //we are only performing conversions if update is required to cloud, otherwise this message will be discarded
                if(requireUpdate == true)
                {
                   buf[63] = 0;           //set null at end of buffer as safety to avoid overrun in search  

                   ptr = strchr((char*)buf, ',') + 1;  //search and skip first comma, just after $GNRMC
                   gpsData.UTC = atol(ptr);            //read UTC from GPS

                   ptr = strchr(ptr, ',') + 1;         //search and skip next comma
                   gpsData.status = *ptr;              //read GPS status flag

                   ptr = strchr(ptr, ',') + 1;         //search and skip next comma
                   i = atoi(ptr)/100;                  //read latitude and perform conversion for DDM to DD
                   gpsData.Latitude = strtod(ptr+2, NULL); // !this is not a grammar mistake, MPLAB may not understand it, but compiles fine.
                   gpsData.Latitude = (gpsData.Latitude/60) + i;

                   ptr = strchr(ptr, ',') + 1;         //search and skip next comma    
                   gpsData.NS = *ptr;                  //read North/South indicator

                   ptr = strchr(ptr, ',') + 1;         //search and skip next comma
                   i = atoi(ptr)/100;                  //read longitude and perform conversion for DDM to DD
                   gpsData.Longitude = strtod(ptr+3, NULL); //!this is not a grammar mistake, MPLAB may not understand it, but compiles fine.
                   gpsData.Longitude = (gpsData.Longitude/60) + i;

                   ptr = strchr(ptr, ',') + 1;         //search and skip next comma    
                   gpsData.EW= *ptr;                   //read East/West indicator

                   ptr = strchr(ptr, ',') + 1;         //search and skip next comma    
                   gpsData.Speed = strtod(ptr, NULL);  //read speed. No grammar mistake here to!
                   gpsData.Speed *= 1.852;             //conver from knots to km/h  
                   
                   updateReady = true;                  //update is ready to be published on cloud
                   requireUpdate = false;
                }
            }
        }
        else if(w > 6) UART1_Read(buf, w-6); //keep few bytes in case there is some part of $GNRMC 
    }
}
