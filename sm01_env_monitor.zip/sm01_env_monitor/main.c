/*******************************************************************
 *  Cloud connected environment monitoring system.
 *******************************************************************
 * File:    main.c
 * Company: SciFlair Ltd.
 * Notes: 
 *    1) Compiler XC16 v1.25 was used to compile this project,  
 *       using another version might produce errors. 
 * 
 * Copyright (C)2019 SciFlair Ltd. - All Rights Reserved.
 * 
 * You may use, modify, copy and distribute these codes to be used 
 * solely on AXINO SM01 modules.
 *   
 * Author            Date        Comment
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * AAC               19/08/2019  Original release
 ********************************************************************/

#include <xc.h>
#include "sm01_lib/sm01.h"
#include <string.h>

#define AIR_QUALITY_SENS_IO GPIO15
#define LIGHT_SENS_IO GPIO13
#define SHT3X_I2C_ADR 0x44

//Application variables
static uint16_t updateInterval = 120;
static bool updateReady = false;

static uint16_t temperature;
static uint16_t humidity; 
static uint16_t airQuality;
static uint16_t lightIntensity;
        
//Function prototypes
void ApplicationTasks(void);

//Main program begins here
int main(void)
{
    SM01_Init(SM01_MODULE_IN_USE, SM01_MODE_AUTO); //Initialize SM01 hardware and all its required modules
    EZCOM_SetTrace(1); //Enable EZCOM stack operation to be reported on console

    GPIO_Mode(AIR_QUALITY_SENS_IO, ANALOG);  //Air Quality Sensor
    GPIO_Mode(LIGHT_SENS_IO, ANALOG);        //Light Sensor
    I2C1_Open();                             //Open I2C1 Port   
    
    while(1)
    {
        ApplicationTasks(); //Process application related tasks
        
        if(SW_IO == 0 || updateReady == true) //publish to cloud if update is required, or switch on module is pressed 
        {
            char buf[100];
            updateReady = false;

            sprintf(buf, "\r\nTemperature: %u, Humidity: %u, AirQuality: %u, LightIntensity: %u", temperature,  humidity, airQuality, lightIntensity); 

            printf("\r\nSending Message to Cloud {%s}", buf);
            if(EZCOM_IsConnected())
            {
                if(EZCOM_Publish(1, buf, true, EZCOM_QOS_1))
                    printf("\r\nMessage Sent!");
                else printf("\r\nMessage Failed!");
            }
            else printf("\r\nCloud is not connected");
            TickWait(500);
            //SM01_Sleep(10);
        }
    }
}

// This function is called by sm01 stack every time a new message is received from cloud
bool EZCOM_OnReceive(uint32_t from, uint32_t topic, uint8_t* msg, uint16_t msglen)
{
    if(msglen >=6 && strncmp("update", (char*)msg,6) == 0)
    {
        printf("\r\nUpdate request is received ");
        updateReady = true;
    }
    else if(msglen >=11 && strncmp("interval=", (char*)msg,9) == 0)
    {
        updateInterval = atoi((char*)msg+9);
        if(updateInterval < 30) updateInterval = 30;        //limit max value to 30 seconds
        if(updateInterval > 3600) updateInterval = 3600;    //limit max value to 3600 seconds (1 hour) 
        printf("\r\nUpdate interval is set to %u Seconds", updateInterval);
    }
    else printf("\r\nUnknown Message");
    
    return true;
}

//This function process task related to Application functionality
void ApplicationTasks(void)
{
    static uint32_t tick = 0;
    static uint32_t lastUpdateTime = 0;

    //check the time in seconds since last update and set flag for update if  
    //update interval is past.
    if(((SM01_UpTime() - lastUpdateTime) >  updateInterval))
    {
        lastUpdateTime = SM01_UpTime();   
        updateReady = true;        
    }

    if(TickElapsed(tick) > 2000) //perform sensor readouts every 2 seconds
    {
        uint8_t buf[8];
        double x;
        tick = Tick();
        lightIntensity = GPIO_Read(LIGHT_SENS_IO);      //Read value from light sensor
        airQuality = GPIO_Read(AIR_QUALITY_SENS_IO);    //Read value from air quality sensor
        
        buf[0] = 0x2C;  //SHT3x I2C command MSB for measurement readouts
        buf[1] = 0x06;  //SHT3x I2C command LSB for measurement readouts
        I2C1_Transfer(SHT3X_I2C_ADR, buf, 2, 6);    //Perform I2C transfer, write 2 bytes command and the read 6 byte data    
        
        temperature = buf[0];                       //copy data from buffer to temperature variable
        temperature = (temperature << 8) | buf[1];
        x = temperature;                            
        x =  -45 + 175 * (x / 0xffff);              //convert raw sensor values into a physical scale (temperature in �C)
        temperature = x;
        
        humidity = buf[3];                          //copy data from buffer to humidity variable
        humidity = (humidity << 8) | buf[4];
        x = humidity;                               
        x =  100 * (x / 0xffff);                    //convert raw sensor values into a physical scale (humidity in %RH)  
        humidity = x;

        printf("\r\nTemperature: %u, Humidity: %u, AirQuality: %u, LightIntensity: %u", temperature,  humidity, airQuality, lightIntensity);    
    }
}
